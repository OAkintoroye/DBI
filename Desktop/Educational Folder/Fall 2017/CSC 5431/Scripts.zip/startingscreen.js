﻿function loadStoryGame()
{
	Application.LoadLevel("Backstory");
}

function restartGame()
{
	Application.LoadLevel("Startingscreen");
}